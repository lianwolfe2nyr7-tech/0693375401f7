// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Map canopy coverage"); }
int main(){
  announce();
  return lionss_run_workload("canopy");
}
