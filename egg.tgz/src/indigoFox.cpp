// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Trace indigo path"); }
int main(){
  announce();
  return lionss_run_workload("indigoFox");
}
