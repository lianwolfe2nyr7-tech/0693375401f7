// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply ACES tonemap\n", stdout);
  return lionss_run_workload("tonemap_aces");
}
