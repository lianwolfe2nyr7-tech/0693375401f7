// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Shift pitch 2x");
  std::fflush(stdout);
  return lionss_run_workload("pitchShift2x");
}
