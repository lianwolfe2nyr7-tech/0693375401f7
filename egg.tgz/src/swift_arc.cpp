// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Elide retain and release"); }
int main(){
  announce();
  return lionss_run_workload("swift_arc");
}
